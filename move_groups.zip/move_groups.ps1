﻿###############
# File must be in the format of of SamAccountNames in 2 columns
# Columns Headers: old_name,new_name
###############

$users = import-csv file.csv

#make sure creds are bbc\username
#$creds = Get-Credential
#Connect-QADService DCLOCAL01 -Credential $creds

foreach ($user in $users) {
    $old_groups = (Get-QADUser $user.old_name).memberof
    foreach ($group in $old_groups) {
      Add-QADGroupMember -Identity $group -Member $user.new_name
    }
}
